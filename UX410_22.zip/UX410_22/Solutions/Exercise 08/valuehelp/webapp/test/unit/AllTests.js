sap.ui.define([
	"student00sap.training./valuehelp/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
