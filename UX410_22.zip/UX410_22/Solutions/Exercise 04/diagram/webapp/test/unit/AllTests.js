sap.ui.define([
	"student00saptraining/diagram/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
