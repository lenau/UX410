/* global QUnit */

sap.ui.require(["student00/sap/training/diagram/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
