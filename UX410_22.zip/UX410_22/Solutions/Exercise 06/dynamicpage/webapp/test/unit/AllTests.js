sap.ui.define([
	"student00/sap/training/dynamicpage/test/unit/controller/App.controller"
], function () {
	"use strict";
});
