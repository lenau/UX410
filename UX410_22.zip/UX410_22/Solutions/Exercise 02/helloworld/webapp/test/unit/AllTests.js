sap.ui.define([
	"student00sap.training./helloworld/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
