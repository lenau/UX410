sap.ui.define([
	"student00sap.training./startnavigation/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
