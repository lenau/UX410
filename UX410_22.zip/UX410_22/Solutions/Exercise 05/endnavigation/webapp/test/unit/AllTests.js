sap.ui.define([
	"student00sap.training./endnavigation/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
