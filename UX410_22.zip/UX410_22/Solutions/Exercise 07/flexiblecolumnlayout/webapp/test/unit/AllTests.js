sap.ui.define([
	"student00/sap/training/flexiblecolumnlayout/test/unit/controller/App.controller"
], function () {
	"use strict";
});
